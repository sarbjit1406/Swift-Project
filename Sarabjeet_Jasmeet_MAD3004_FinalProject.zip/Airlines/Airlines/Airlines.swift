//
//  Airlines.swift
//  Airlines
//
//  Created by MacStudent on 2018-08-01.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class AirlineType : IDisplay{
    private var airlineID : Int?
    private var airlineDescription : String?
    private var airlineType : String?
    private var category : AirlinesCategory?
    
    var AirlineID : Int? {
        get{ return self.airlineID }
        set{ self.airlineID = newValue}
    }
    var AirlineDescription : String? {
        get { return self.airlineDescription }
        set { self.airlineDescription = newValue }
    }
    var AirlineType : String? {
        get{ return self.airlineType }
        set{ self.airlineType = newValue}
    }
    
    var Category : AirlinesCategory?{
        get{ return self.category}
        set{ self.category = newValue}
    }
    
    
    //designated
    init(){
        self.airlineID = 0
        self.airlineDescription = ""
        self.airlineType = ""
        self.category = AirlinesCategory.None
    }
    
    
    init (airlineID: Int, airlineDescription: String, airlineType: String, category: AirlinesCategory){
        self.airlineID = airlineID
        self.airlineDescription = airlineDescription
        self.airlineType = airlineType
        self.category = category
    }
    
    
    func displayData() -> String {
        var returnData = ""
        if self.airlineID != nil {
            returnData += "Airline ID : \(self.airlineID ?? 0)"
        }
        if self.airlineDescription != nil {
            returnData += "Arline description : \(self.airlineDescription ?? "")"
        }
        if self.airlineType != nil {
            returnData += "Airplane type : \(self.airlineType ?? "")"
        }
        if self.category != nil {
            returnData += "Airline type name : \(self.category ?? AirlinesCategory.None)"
        }
        return returnData
    }
}
