//
//  FlightType.swift
//  Airlines
//
//  Created by MacStudent on 2018-08-01.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation



class Flight {
    
    private var flightId : Int?
    private var flight_from : AirportCategory?
    private var flight_to : AirportCategory?
    
    private var flight_date : String?
    private var pType : PlaneTypeCategory?
    private var aType : AirlinesCategory?
    private var pilotId : Int?
    private var pilotName : String?
    private var price : Double?
    
    var FlightId : Int? {
        get { return self.flightId }
        set{ self.flightId = newValue}
    }
    
    var FlightFrom : AirportCategory? {
        get { return self.flight_from }
        set{ self.flight_from = newValue}
    }
    var FlightTo : AirportCategory? {
        get { return self.flight_to }
        set{ self.flight_to = newValue}
    }
    var FlightDate : String? {
        get { return self.flight_date }
        set{ self.flight_date = newValue}
    }
    var PType : PlaneTypeCategory? {
        get { return self.pType }
        set{ self.pType = newValue}
    }
    var AType : AirlinesCategory? {
        get { return self.aType }
        set{ self.aType = newValue}
    }
    var PilotId : Int? {
        get { return self.pilotId }
        set{ self.pilotId = newValue}
    }
    var PilotName : String? {
        get { return self.pilotName }
        set{ self.pilotName = newValue}
    }
    var Price : Double? {
        get { return self.price }
        set{ self.price = newValue}
    }
    
    init() {
        self.flightId = 0
        self.flight_from = AirportCategory.None
        self.flight_to = AirportCategory.None
        
        self.flight_date = ""
        self.pType = PlaneTypeCategory.None
        self.aType = AirlinesCategory.None
        self.pilotId = 0
        self.pilotName = ""
        self.price = 0.0
    }
    
    init(flightId: Int, flight_from: AirportCategory, flight_to: AirportCategory, flight_date: String, pType: PlaneTypeCategory, aType: AirlinesCategory, pilotId: Int, pilotName: String, price: Double) {
        self.flightId = flightId
        self.flight_from = flight_from
        self.flight_to = flight_to
        
        self.flight_date = flight_date
        self.pType = pType
        self.aType = aType
        self.pilotId = pilotId
        self.pilotName = pilotName
        self.price = price
    }
    
    func displayData() -> String {
        var returnData = ""
        if self.flightId != nil {
            returnData += "\n Flight ID : \(self.flightId!)"
        }
        if self.flight_from != nil {
            returnData += "\n Flight from : \(self.flight_from!)"
        }
        if self.flight_to != nil {
            returnData += "\n Flight to : \(self.flight_to!)"
        }
        if self.flight_date != nil {
            returnData += "\n Flight date : \(self.flight_date!)"
        }
        if self.pType != nil {
            returnData += "\n Flight plane type : \(self.pType!)"
        }
        if self.aType != nil {
            returnData += "\n Flight airlines : \(self.aType!)"
        }
        if self.pilotId != nil {
            returnData += "\n Pilot Id : \(self.pilotId!)"
        }
        if self.pilotName != nil {
            returnData += "\n Pilot Name : \(self.pilotName!)"
        }
        if self.price != nil {
            returnData += "\n Flight price : \(self.price!)"
        }
//        returnData += "\t \(self.flightId ?? 0) ------\(self.flight_from ?? AirportCategory.None) ------ \(self.flight_to ?? AirportCategory.None) ------ \(self.flight_class ?? FlightCategory.None) ------ \(self.flight_date ?? "")"
        return returnData
    }
    
    func displayFlight() {
        print("Enter Flight Id : ")
        self.flightId = (Int)(readLine()!)
        
        print("Enter Flight from : ")
        for flight_from in AirportCategory.allCases
        {
            print("Enter \(flight_from.rawValue) for  \(flight_from)")
        }
        
        print("Enter Flight to : ")
        for flight_to in AirportCategory.allCases
        {
            print("Enter \(flight_to.rawValue) for  \(flight_to)")
        }
        
        print("Enter Flight date : ")
        self.flight_date = readLine()!
        
        print("Enter Flight plane type: ")
        for pType in PlaneTypeCategory.allCases
        {
            print("Enter \(pType.rawValue) for  \(pType)")
        }
        print("Enter Flight airlines type: ")
        for aType in AirlinesCategory.allCases
        {
            print("Enter \(aType.rawValue) for  \(aType)")
        }
        print("Enter Pilot id : ")
        self.pilotId = (Int)(readLine()!)
        print("Enter Pilot Name : ")
        self.pilotName = readLine()!
        print("Enter Flight price : ")
        self.price = (Double)(readLine()!)
        
        //        for category in AirportCategory.allCases{
        //            print("Enter \(flight_from.rawValue) for  \(flight_from)")
        //        }
        //        let choice = (Int)(readLine()!) ?? 5
        //        self.flight_from = AirportCategory(rawValue: choice!)!
    }
    
    
}
