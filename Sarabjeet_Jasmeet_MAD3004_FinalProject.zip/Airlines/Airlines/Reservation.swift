//
//  Reservation.swift
//  Airlines
//
//  Created by Sai Teja Daggubati on 2018-08-01.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

typealias flightData = ( flightId: Int , flight : Flight)

class Reservation : IDisplay {
    
    var reservationId : Int?
    var reservationDate : Date
    var reservationStatus : StatusCategory?
    var reservationMeal : MealCategory?
    var resevationClass : FlightCategory?
    var reserveReservation : [flightData]
    var passangerDetails : Passenger
    var flightDetails : Flight
    var amount : Double?
    var dataHelper = DataHelper()
    
    init(){
        self.reservationId = 0
        self.reservationDate = DateFormatter().date(from: "")!
        self.reservationStatus = StatusCategory.NoReservation
        self.reservationMeal = MealCategory.None
        self.resevationClass = FlightCategory.None
        self.reserveReservation = []
        self.amount = 0.0
        self.passangerDetails = Passenger()
        self.flightDetails = Flight()
       
        
    }
    
    var ReservationId : Int?{
        get{ return self.reservationId }
        set{ self.reservationId = newValue }
    }
    var ReservationDate : Date{
        get{ return self.reservationDate }
        set{ self.reservationDate = newValue }
    }
    var ReservationStatus : StatusCategory{
        get{ return self.reservationStatus ?? StatusCategory.NoReservation}
        set{ self.reservationStatus = newValue }
    }
    var ReservationMeal : MealCategory{
        get{ return self.reservationMeal ?? MealCategory.None}
        set{ self.reservationMeal = newValue }
    }
    var ResevationClass : FlightCategory{
        get{ return self.resevationClass ?? FlightCategory.None}
        set{ self.resevationClass = newValue }
    }
    var Amount : Double? {
        get{
            //let meal : Double = 50.00
            var totalAmount = 0.0
            if !self.reserveReservation.isEmpty{
                for (_, fli) in self.reserveReservation {
                    totalAmount = fli.Price! + 50.00
                }
            }
            return totalAmount
        }
    }
    var PassangerDetails : Passenger {
        get{ return self.passangerDetails }
        set{ self.passangerDetails = newValue }
    }
    var FlightDetails : Flight {
        get{ return self.flightDetails }
        set{ self.flightDetails = newValue }
    }
    
     func displayData() -> String {
        var returnData = ""
        
        returnData += "\n Passanger ID : \(self.passangerDetails.passengerName ?? "")"
        returnData += "\n Passanger Email : \(self.passangerDetails.email ?? "")"
        returnData += "\n Passanger Contact : \(self.passangerDetails.mobile ?? "")"
        returnData += "\n Reservation Id : \(self.ReservationId ?? 0)"
        returnData += "\n Reservation Date : \(self.ReservationDate)"
        returnData += "\n Reservation Status : \(self.reservationStatus ?? StatusCategory.Confirmed)"
        returnData += "\n Reservation meal type : \(self.reservationMeal ?? MealCategory.None)"
        returnData += "\n Reservation Class type : \(self.resevationClass ?? FlightCategory.None)"
        
        
        returnData += "\n Flight list : "
        if !self.reserveReservation.isEmpty{
            for (_, flight) in self.reserveReservation{
                returnData += "\n\t\(flight.displayData())"
                //returnData += "\n\t\(pass.displayData())"
            }
        }else{
            returnData += "\n No reservation"
        }
        returnData += "\n Total Amount : \(self.amount!)"
        return returnData
    }
    
    func displayMeal() -> MealCategory{
        print("Select Meal Type : ")
        for MealType in MealCategory.allCases
        {
            print("Enter \(MealType.rawValue) for \(MealType)")
        }
        let choice = (Int)(readLine()!)!
        return MealCategory(rawValue: choice)!
    }
    
    func displayClass() -> FlightCategory{
        print("Select Class Type : ")
        for ClassType in FlightCategory.allCases
        {
            print("Enter \(ClassType.rawValue) for \(ClassType)")
        }
        let choices = (Int)(readLine()!)!
        return FlightCategory(rawValue: choices)!
    }
    
    func addReservation(){
        
        dataHelper.displayFlightType()
        print("Please enter flight ID to choose flight from the list : ")
        
        let selectedFlightID : Int = (Int)(readLine()!)!
        
        if let selectedFlight = dataHelper.searchFlight(flightId: selectedFlightID)
       // if dataHelper.searchFlight(flightId: selectedFlightID) != nil
        {
            self.ReservationId = selectedFlightID
            self.ReservationDate = Date()
            self.reserveReservation += [(flightId : selectedFlightID, flight : selectedFlight)]
            self.passangerDetails = Passenger().registerPassenger()
            self.reservationStatus = StatusCategory.Confirmed
            self.reservationMeal = displayMeal()
            self.resevationClass = displayClass()
        }
        else{
            print("Sorry.. No reservation")
        }
        
    }
    
    func cancelReservation(){
        if !reserveReservation.isEmpty {
            print("Review your booking \n \(self.displayData())")
            
            print("Please enter flight ID to cancel from the booking : ")
            let selectedFlightID : Int = (Int)(readLine()!)!
            var flightIndex = -1
            
            for (index, flight) in self.reserveReservation.enumerated(){
                if (flight.flightId == selectedFlightID){
                    flightIndex = index
                }
            }
            
            if flightIndex != -1{
                self.reserveReservation.remove(at: flightIndex)
                print("The flight is cancelled from your booking")
            }
            else{
                print("You have booked no flight in your booking")
            }
        }
    }
    
}
