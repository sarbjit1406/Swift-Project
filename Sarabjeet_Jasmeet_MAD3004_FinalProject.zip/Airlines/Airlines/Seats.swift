//
//  Seats.swift
//  Airlines
//
//  Created by Sai Teja Daggubati on 2018-08-01.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Seats{
    var seatcode = [[0,0,0], [0,0,0]]
    func busclass(){
        print(" First Class \n")
        for row in 0...1{
            for col in 0...1{
                if col==0{
                    print( "A"+"\(row + 1)", terminator: "\t")
                }
                if col==1{
                    print("B"+"\(row + 1)", terminator: "\t")
                }
            }
            print("\n")
        }
        
        print(" Business Class \n")
        for row in 0...2{
            for col in 0...2{
                if col==0{
                    print( "X"+"\(row + 1)", terminator: "\t")
                }
                if col==1{
                    print("Y"+"\(row + 1)", terminator: "\t")
                }
                if col==2{
                    print("Z"+"\(row + 1)", terminator: "\t")
                }
            }
            print("\n")
        }
        print(" Economy Class \n")
        for row in 0...2{
            for col in 0...2{
                if col==0{
                    print("E"+"\(row + 1)", terminator: "\t")
                }
                if col==1{
                    print("F"+"\(row + 1)", terminator: "\t")
                }
                if col==2{
                    print("G"+"\(row + 1)", terminator: "\t")
                }
            }
            print("\n")
        }
        
    }
}
