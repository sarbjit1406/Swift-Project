//
//  Passenger.swift
//  Airlines
//
//  Created by MacStudent on 2018-08-01.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Passenger{
    private var passengerID : Int?
    private var passportNo : String?
    var passengerName : String?
    var mobile : String?
    var email : String?
    private var address : String?
    private var age : Int?
    
    //stored property
    
    var PassengerID : Int? {
        get{return self.passengerID}
        set{self.passengerID = newValue}
    }
    var PassportNo: String? {
        get{return self.passportNo}
        set{self.passportNo = newValue}
    }
    
    var PassengerName: String? {
        get{return self.passengerName}
        set{self.passengerName = newValue}
    }
    var Mobile: String? {
        get{return self.mobile}
        set{self.mobile = newValue}
    }
    var  Email : String? {
        get{return self.email}
        set{self.email = newValue}
    }
    var  Address : String? {
        get{return self.address}
        set{self.address = newValue}
    }
    
    var  Age : Int? {
        get{return self.age}
        set{self.age = newValue}
    }
    init(){
        self.passengerID = 0
        self.passportNo = ""
        self.passengerName = ""
        self.mobile = ""
        self.email = ""
        self.address = ""
        self.age = 0
    }
    
    //parameterized initializer
    
    init(passengerID : Int,  passportNo : String, passengerName: String, mobile: String, email: String, address: String, age: Int ){
        
        self.passengerID = passengerID
        self.passportNo = passportNo
        self.passengerName = passengerName
        self.mobile = mobile
        self.email = email
        self.address = address
        self.age = age
    }
    
    
    
    
    func displayData() -> String{
        var returnData = ""
        
        if self.passengerID != nil {
            returnData += "(Passenger ID : \(self.passengerID ?? 0)"
        }
        
        if self.passportNo != nil {
            returnData += " \n PassportNo : " + self.passportNo!
        }
        if self.passengerName != nil {
            returnData += " \n PassengerName :" + self.passengerName!
        }
        if self.mobile != nil {
            returnData += " \n Mobile No: " + self.mobile!
        }
        if self.email != nil {
            returnData += " \n Passenger Email : " + self.email!
        }
        if self.address != nil {
            returnData += " \n PassengerAddress : " + self.address!
        }
        if self.age != nil {
            returnData += "(\n Age: \(self.age ?? 0))"
        }
        
        return returnData
    }
    func registerPassenger() -> Passenger{
        print("Enter Passenger ID : ")
        self.passengerID = (Int)(readLine()!)
        print("Enter PassportNo : ")
        self.passportNo = readLine()!
        print("Enter PassengerName : ")
        self.passengerName = readLine()!
        print("Enter Mobile No : ")
        self.mobile = readLine()!
        print("Enter Passenger Email : ")
        self.email = readLine()!
        print("Enter Passenger Address : ")
        self.address = readLine()!
        print("Enter Age : ")
        self.age = (Int)(readLine()!)
        return self
    }
}

