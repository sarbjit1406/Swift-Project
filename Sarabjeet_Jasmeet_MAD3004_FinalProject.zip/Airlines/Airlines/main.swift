//
//  main.swift
//  Airlines
//
//  Created by MacStudent on 2018-08-01.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

let dataHelper = DataHelper()
var passenger = Passenger()
var employee = Employee()
var reserve = Reservation()

var choice = 1

while choice != 8{
    print("\n....We never forget you have a choice.")
    print("\t 1 : Inquery of Plane Type")
    print("\t 2 : Inquery of Airplane Type")
    print("\t 3 : Display employeers")
    print("\t 4 : Add your details")
    print("\t 5 : Show flight schedules")
    print("\t 6 : Book reservation")
    print("\t 7 : Show ticket")
    print("\t 8 : Cancel reservation")
    print("\t 9 : Exit ")
    print("-----------------------------------------")
    print("Enter you choice : ")
    choice = (Int)(readLine()!)!
    
    switch choice{
    case 1:
        dataHelper.displayPlaneType()
    case 2:
        dataHelper.displayAirlinesType()
    case 3:
        employee.newEmployee()
    case 4:
        passenger.registerPassenger()
    case 5:
        dataHelper.displayFlightType()
    case 6:
        reserve.addReservation()
    case 7:
        print(reserve.displayData())
    case 8:
        reserve.cancelReservation()
    case 9:
        exit(0)
    default:
        print("Please enter valid menu option.")
    }
}
