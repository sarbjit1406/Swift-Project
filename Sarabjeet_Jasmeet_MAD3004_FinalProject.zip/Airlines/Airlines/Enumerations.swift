//
//  Enumerations.swift
//  Airlines
//
//  Created by MacStudent on 2018-08-01.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
enum PlaneTypeCategory : Int, CaseIterable {
    case Airbus = 1
    case Boeing
    case Bombardier
    case Textron
    case Spirit
    case None
}

enum AirlinesCategory : Int, CaseIterable {
    case American = 1
    case United
    case Delta
    case Northwest
    case Alaska
    case None
}

enum AirportCategory : Int, CaseIterable {
    case Pearson = 1
    case Vancouver
    case Calgary
    case Victoric
    case Regina
    case None
}

enum FlightCategory : Int, CaseIterable {
    case Bussiness = 1
    case Economy
    case First
    case None
}

enum MealCategory : Int, CaseIterable{
    case Vegetarian = 1
    case Non_Vegeterian
    case None
}

enum StatusCategory : Int, CaseIterable{
    case Confirmed = 1
    case Cancelled
    case Placed
    case NoReservation
}

extension CaseIterable where Self: Hashable {
    static var allCases: [Self] {
        return [Self](AnySequence { () -> AnyIterator<Self> in
            var raw = 0
            var first: Self?
            return AnyIterator {
                let current = withUnsafeBytes(of: &raw) { $0.load(as: Self.self) }
                if raw == 0 {
                    first = current
                } else if current == first {
                    return nil
                }
                raw += 1
                return current
            }
        })
    }
}
