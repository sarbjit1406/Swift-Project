//
//  FlightType.swift
//  AirlinesProject
//
//  Created by Sai Teja Daggubati on 2018-07-28.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Flight {
    
    private var flightId : Int?
    private var flight_from : AirportCategory?
    private var flight_to : AirportCategory?
    private var flight_class : FlightCategory?
    private var flight_date : String?
    
    var FlightId : Int? {
        get { return self.flightId }
        set{ self.flightId = newValue}
    }
    
    var FlightFrom : AirportCategory? {
        get { return self.flight_from }
        set{ self.flight_from = newValue}
    }
    var FlightTo : AirportCategory? {
        get { return self.flight_to }
        set{ self.flight_to = newValue}
    }
    var FlightClass : FlightCategory? {
        get { return self.flight_class }
        set{ self.flight_class = newValue}
    }
    var FlightDate : String? {
        get { return self.flight_date }
        set{ self.flight_date = newValue}
    }
    
    init() {
        self.flightId = 0
        self.flight_from = AirportCategory.None
        self.flight_to = AirportCategory.None
        self.flight_date = ""
        self.flight_class = FlightCategory.None
    }
    
    init(flightId: Int, flight_from: AirportCategory, flight_to: AirportCategory, flight_class : FlightCategory, flight_date: String) {
        self.flightId = flightId
        self.flight_from = flight_from
        self.flight_to = flight_to
        self.flight_date = flight_date
        self.flight_class = flight_class
    }
    
    func displayData() -> String {
        var returnData = ""
        returnData += "\t \(self.flightId ?? 0) ------\(self.flight_from ?? AirportCategory.None) ------ \(self.flight_to ?? AirportCategory.None) ------ \(self.flight_class ?? FlightCategory.None) ------ \(self.flight_date ?? "")"
        return returnData
    }
    
    func displayFlight() {
        print("Enter Flight Id : ")
       self.flightId = (Int)(readLine()!)
        
        print("Enter Flight from : ")
        for flight_from in AirportCategory.allCases
        {
            print("Enter \(flight_from.rawValue) for  \(flight_from)")
        }
        
        print("Enter Flight to : ")
        for flight_to in AirportCategory.allCases
        {
            print("Enter \(flight_to.rawValue) for  \(flight_to)")
        }
        
        print("Enter Flight class : ")
        for flight_class in FlightCategory.allCases
        {
            print("Enter \(flight_class.rawValue) for  \(flight_class)")
        }
        
        print("Enter Flight to : ")
        self.flight_date = readLine()!
        
//        for category in AirportCategory.allCases{
//            print("Enter \(flight_from.rawValue) for  \(flight_from)")
//        }
//        let choice = (Int)(readLine()!) ?? 5
//        self.flight_from = AirportCategory(rawValue: choice!)!
  }
    
    
}
