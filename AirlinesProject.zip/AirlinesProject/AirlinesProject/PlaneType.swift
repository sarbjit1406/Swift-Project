//
//  PlaneType.swift
//  AirlinesProject
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class PlaneType : IDisplay{
    private var planeTypeId : String?
    private var discription : String?
    private var noOfSeats : Int?
    private var planeName : PlaneTypeCategory?
    
    var PlaneTypeId : String? {
        get{ return self.planeTypeId }
        set{ self.planeTypeId = newValue }
    }
    var Discription : String? {
        get{ return self.discription }
        set{ self.discription = newValue }
    }
    var NoOfSeats : Int? {
        get{ return self.noOfSeats }
        set{ self.noOfSeats = newValue }
    }
    var PlaneName : PlaneTypeCategory? {
        get{ return self.planeName }
        set{ self.planeName = newValue }
    }
    
    
    //designated
    init() {
        self.planeTypeId = ""
        self.discription = ""
        self.noOfSeats = 0
        self.PlaneName = PlaneTypeCategory.None
    }
    
    init(planeTypeId : String, discription : String, noOfSeats : Int, planeName: PlaneTypeCategory) {
        self.planeTypeId = planeTypeId
        self.discription = discription
        self.noOfSeats = noOfSeats
        self.planeName = planeName
    }
    
    func displayData() -> String {
        var returnData = ""
        if self.planeTypeId != nil {
            returnData += "Plane type ID : \(self.planeTypeId ?? "")"
        }
        if self.discription != nil {
            returnData += "Plane type discription : \(self.discription ?? "")"
        }
        if self.noOfSeats != nil {
            returnData += "Plane type no. of seats : \(self.noOfSeats ?? 0)"
        }
        if self.planeName != nil {
            returnData += "Plane type name : \(self.planeName ?? PlaneTypeCategory.None)"
        }
        return returnData
    }
}
