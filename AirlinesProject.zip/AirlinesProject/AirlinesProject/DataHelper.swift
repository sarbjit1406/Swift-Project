//
//  DataHelper.swift
//  AirlinesProject
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class DataHelper{
    var PlaneTypeList = [String : PlaneType]()
    var AirlineTypeList = [Int : AirlineType]()
    var FlightTypeList = [Int : Flight]()
    
    init() {
        self.loadPlaneTypeData()
        self.loadAirlinesTypeData()
        self.loadFlight()
        
    }
    func loadPlaneTypeData(){
        PlaneTypeList = [:]
        
        let p1 = PlaneType(planeTypeId: "A111", discription: "Two engines, single aisle, originally Bombardier CSeries", noOfSeats: 130, planeName: PlaneTypeCategory.Airbus)
        PlaneTypeList[p1.PlaneTypeId!] = p1
        
        let p2 = PlaneType(planeTypeId: "A112", discription: "They are short- to medium-range, narrow-body jet airliners powered by two engines.", noOfSeats: 120, planeName: PlaneTypeCategory.Boeing)
        PlaneTypeList[p2.PlaneTypeId!] = p2
        
        let p3 = PlaneType(planeTypeId: "A113", discription: "Series of twin-engine, medium-range, turboprop airliners. Introduced by de Havilland Canada (DHC) in 1984, they are now produced by Bombardier Aerospace.", noOfSeats: 128, planeName: PlaneTypeCategory.Bombardier)
        PlaneTypeList[p3.PlaneTypeId!] = p3
        
        let p4 = PlaneType(planeTypeId: "A114", discription: "Engineers reviewed over 12 design configurations that would meet their goals and shortlisted four designs.", noOfSeats: 140, planeName: PlaneTypeCategory.Textron)
        PlaneTypeList[p4.PlaneTypeId!] = p4
        
        let p5 = PlaneType(planeTypeId: "A115", discription: "Spirit currently flies to 65 destinations throughout Central America, the Caribbean, South America, and the United States. ", noOfSeats: 110, planeName: PlaneTypeCategory.Spirit)
        PlaneTypeList[p5.PlaneTypeId!] = p5
    }
    func displayPlaneType(){
        print("Plane type details")
        Util.drawLine()
        print("\t ID \t\t Description \t\t\t\t  No of seats \t\t PlaneType Name")
        for (_, value) in self.PlaneTypeList.sorted(by: { $0.key < $1.key }){
            Util.drawLine()
            print("\t \(value.PlaneTypeId!) ------ \(value.Discription!) ------ \(value.NoOfSeats!) ------ \(value.PlaneName!)")
        }
        Util.drawLine()
    }
    //    func displayPlaneType(){
    //        //closures
    //        for (_,plane) in PlaneTypeList.sorted(by: {$0.key < $1.key}){
    //            print("\(plane.displayData())")
    //        }
    //    }
    func loadAirlinesTypeData(){
        AirlineTypeList = [:]
        
        let a1 = AirlineType(airlineID: 101, airlineDescription: "It is the world's largest airline when measured by fleet size, revenue, scheduled passengers carried, scheduled passenger-kilometers flown, and number of destinations served.", airlineType: "BUSINESS CLASS SERVICES, COMBINATIONAL CARRIER SERVICES, LOW COST CARRIERS", category: AirlinesCategory.American)
        AirlineTypeList[a1.AirlineID!] = a1
        
        let a2 = AirlineType(airlineID: 102, airlineDescription: "It is the world's third-largest airline when measured by revenue, after American Airlines and Delta Air Lines.", airlineType: "CHARTER SERVICES, COMBINATIONAL CARRIER SERVICES", category: AirlinesCategory.United)
        AirlineTypeList[a2.AirlineID!] = a2
        
        let a3 = AirlineType(airlineID: 103, airlineDescription: "Major United States airline, with its headquarters and largest hub at Hartsfield–Jackson Atlanta International Airport in Atlanta, Georgia.", airlineType: "COMBINATIONAL CARRIER SERVICES, LOW COST CARRIERS", category: AirlinesCategory.Delta)
        AirlineTypeList[a3.AirlineID!] = a3
        
        let a4 = AirlineType(airlineID: 104, airlineDescription: "Delta the largest airline in the world until the American Airlines-US Airways merger on December 9, 2013.", airlineType: "LOW COST CARRIERS, FULL CARRIER SERVICES", category: AirlinesCategory.Northwest)
        AirlineTypeList[a4.AirlineID!] = a4
        
        let a5 = AirlineType(airlineID: 105, airlineDescription: "The fifth-largest airline in the United States, Alaska Airlines is a major air carrier and, along with its sister airline Horizon Air, is part of the Alaska Air Group.", airlineType: "CHARTER SERVICES, BUSINESS CLASS SERVICES", category: AirlinesCategory.Alaska)
        AirlineTypeList[a5.AirlineID!] = a5
        
    }
    
    func displayAirlinesType(){
        print("Airline type details")
        Util.drawLine()
        print("\t ID \t\t Description \t\t\t\t  Type \t\t Alirline")
        for (_, value) in self.AirlineTypeList.sorted(by: { $0.key < $1.key }){
            Util.drawLine()
            print("\t \(value.AirlineID!) ------ \(value.AirlineDescription!) ------ \(value.AirlineType!) ------ \(value.Category!)")
        }
        Util.drawLine()
    }
    
    func loadFlight(){
        FlightTypeList = [:]
        
        let f1 = Flight(flightId: 111, flight_from: AirportCategory.Pearson, flight_to: AirportCategory.Vabcouver, flight_class: FlightCategory.Bussiness, flight_date: "04/08/2019")
        FlightTypeList[(f1.FlightId!)] = f1
        
        let f2 = Flight(flightId: 112, flight_from: AirportCategory.Pearson, flight_to: AirportCategory.Vabcouver, flight_class: FlightCategory.Economy, flight_date: "05/08/2019")
        FlightTypeList[(f2.FlightId!)] = f2
    }
    
    func displayFlightType(){
        print("Flight details")
        Util.drawLine()
        print("\t ID \t\t Flight_From \t\t\t\t  Flight_To \t\t Flight_Class \t\t Flight_Date")
        for (_, value) in self.FlightTypeList.sorted(by: { $0.key < $1.key }){
            Util.drawLine()
            print("\t \(value.FlightId!) ------ \(value.FlightFrom!) ------ \(value.FlightTo!) ------ \(value.FlightClass!)------ \(value.FlightDate!)")
        }
        Util.drawLine()
    }
    
}
