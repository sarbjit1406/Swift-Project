//
//  Employee.swift
//  Project
//
//  Created by MacStudent on 2018-07-21.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Employee{
    private var empID : Int?
    private var empName : String?
    private var empEmail : String?
    private var empMobile : String?
    private var empAddress : String?
    private var empDesignation : String?
    private var empSinNo : String?
    
    init(){
        self.empID = 0
        self.empName = ""
        self.empEmail = ""
        self.empMobile = ""
        self.empAddress = ""
        self.empDesignation = ""
        self.empSinNo = ""
    }
    init(empID: Int, empName: String, empEmail: String, empMobile: String, empAddress: String, empDesignation: String, empSinNo: String){
        
        self.empID = empID
        self.empName = empName
        self.empEmail = empEmail
        self.empMobile = empMobile
        self.empAddress = empAddress
        self.empDesignation = empDesignation
        self.empSinNo = empSinNo
    }
    var EmpID : Int?{
        get{return self.empID}
        set{self.empID = newValue}
    }
    var EmpName : String?{
        get{return self.empName}
        set{self.empName = newValue}
    }
    var EmpEmail : String?{
        get{return self.empEmail}
        set{self.empEmail = newValue}
    }
    var EmpMobile : String?{
        get{return self.empMobile}
        set{self.empEmail = newValue}
    }
    var EmpAddress : String?{
        get{return self.empAddress}
        set{self.empAddress = newValue}
    }
    var EmpDesignation : String?{
        get{return self.empDesignation}
        set{self.empDesignation = newValue}
    }
    var EmpSinNo : String?{
        get{return self.empSinNo}
        set{self.empSinNo = newValue}
    }
    
    func displayData() -> String{
        var returnData = ""
        if self.empID != nil {
            returnData += "Employee ID : \(self.empID ?? 0)"
        }
        
        if self.empName != nil {
            returnData += "\n Employee Name : \(self.empName ?? "Unknown")"
        }
        if self.empEmail != nil {
            returnData += "\n Employee Email : \(self.empEmail ?? "email@mad.com")"
        }
        if self.empMobile != nil {
            returnData += "\n Employee Mobile : \(self.empMobile ?? "Unknown")"
        }
        
        if self.empAddress != nil {
            returnData += "\n Employee address : \(self.empAddress ?? "Unknown")"
        }
        if self.empDesignation != nil {
            returnData += "\n Employee Designation : \(self.empDesignation ?? "email@mad.com")"
        }
        if self.empSinNo != nil {
            returnData += "\n Employee Sin No : \(self.empSinNo ?? "Unknown")"
        }
        return returnData
    }
    
    func newEmployee(){
        print ("Enter Employee ID : ")
        self.empID = (Int)(readLine()!)
        
        print  ("Enter Employee Name : ")
        self.empName = readLine()!
        
        print ("Enter Employee Email : ")
        self.empEmail = readLine()!
        
        print ("Enter Employee Mobile : ")
        self.empMobile = readLine()!
        
        print ("Enter Employee Address : ")
        self.empAddress = readLine()!
        
        print ("Enter Employee Designation : ")
        self.empDesignation = readLine()!
        
        print("Enter Employee's Sin No : ")
        self.empSinNo = readLine()!
        
    }

}

