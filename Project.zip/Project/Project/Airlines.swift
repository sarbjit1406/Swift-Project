//
//  Airlines.swift
//  Project
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Airlines{
    var airline_id: Int?
    var airline_description: String?
    var airline_type: String?
    
    func displayData() -> String {
        var returnData = ""
        
        returnData += "\n Airline ID : \(self.airline_id ?? 0)"
        returnData += "\n Airline description : \(self.airline_description ?? "" )"
        returnData += "\n Airline Type : \(self.airline_type ?? "" )"
        
        return returnData
    }
}
