//
//  DataHelper.swift
//  Project
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class DataHelper{
    var AirlinesList = [Int : Airlines]()
    
    init(){
        self.loadAirlines()
}

    func loadAirlines(){
        let <#name#> = <#value#>
        
  }
}
