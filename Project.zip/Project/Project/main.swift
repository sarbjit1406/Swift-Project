//
//  main.swift
//  Project
//
//  Created by MacStudent on 2018-07-21.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello, World!")
var sarb = Passenger()
print(sarb.displayData())

var sarbjit = Passenger(passengerID : 111, passportNo : "G271672", passengerName : "Sarbjit", mobile : "298-102-2469" , email : "sarb@mad.com", address :  "Topeka Road Toronto", birthDate: Date.init(timeIntervalSince1970: 1))

print("\(sarbjit.displayData())")




//sarb.PassengerID = 111
//sarb.PassportNo = "G271672"
//sarb.PassengerName = "Sarbjit"
//sarb.Mobile = "298-102-2469"
//sarb.Email = "sarb@mad.com"
//sarb.Address = "Toronto"
//sarb.BirthDate = nil

var srb =  Employee()
srb.newEmployee()
print(srb.displayData())

