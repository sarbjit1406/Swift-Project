//
//  DataHelper.swift
//  Project
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class DataHelper{
    var AirlinesList = [Int : Airline]()
    
    init(){
        self.loadAirlines()
        
    }
    
    func loadAirlines() {
         AirlinesList = [:]
        
        do{
            
           let america = try Airline(airline_id: 101, airline_description: "American Airlines, Inc. (AA) is a major United States airline headquartered in Fort Worth, Texas, within the Dallas-Fort Worth metroplex. It is the world's largest airline when measured by fleet size, revenue, scheduled passengers carried, scheduled passenger-kilometers flown, and number of destinations served.", airline_type: "American Airlines", category: AirlinesCategory.American)
        AirlinesList[(america.airline_id!)] = america
        
            
        
        }
        catch{
                print("Error: \(error)")
        }
        
    }
    
}
